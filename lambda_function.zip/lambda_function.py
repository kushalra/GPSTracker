import sys
import logging
import pymysql
import json
import os
import boto3

def lambda_handler(event, context):
    lat = event['lat']
    print(lat)
    


# rds settings
user_name = os.environ['USER_NAME']
password = os.environ['PASSWORD']
rds_host = os.environ['RDS_HOST']
db_name = os.environ['DB_NAME']


logger = logging.getLogger()
logger.setLevel(logging.INFO)

# create the database connection outside of the handler to allow connections to be
# re-used by subsequent function invocations.
try:
    conn = pymysql.connect(host=rds_host, user=user_name, passwd=password, db=db_name, connect_timeout=5)
except pymysql.MySQLError as e:
    logger.error("ERROR: Unexpected error: Could not connect to MySQL instance.")
    logger.error(e)
    sys.exit()


logger.info("SUCCESS: Connection to RDS MySQL instance succeeded")

def lambda_handler(event, context):
    """
    This function creates a new RDS database table and writes records to it
    """
    #message = event['Records'][0]['body']
    #data = json.loads(message)
    lat = event['lat']
    lon = event['lon']
    msg_no = event['msg_no']
    datatime_cor = event['timestamp_1']
    print(lat)
    print(datatime_cor)

    item_count = 0
    sql_string = f"insert into gpsdata (lat, lon, datatime_cor, msg_no) values('{lat}', '{lon}', '{datatime_cor}', {msg_no})"

    with conn.cursor() as cur:
        cur.execute("create table if not exists gpsdata (id INT(11) NOT NULL AUTO_INCREMENT, lat VARCHAR(30) NOT NULL, lon VARCHAR(30) NOT NULL, msg_no INT(10) NOT NULL, datatime_cor DATETIME NOT NULL, PRIMARY KEY(id) )")
        cur.execute(sql_string)
        conn.commit()
    
        cur.execute("select * from gpsdata")
        logger.info("The following items have been added to the database:")
        for row in cur:
            item_count += 1
            logger.info(row)
    conn.commit()

    return "Added %d items to RDS MySQL table" %(item_count) 